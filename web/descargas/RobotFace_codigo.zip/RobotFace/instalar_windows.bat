@echo off
rem Doble clic UNA vez: prepara el robot en este PC (crea el entorno de Python e instala lo necesario).
rem Necesita Python 3.12 de 64 bits instalado desde python.org (con la casilla "Add python.exe to PATH").
chcp 65001 >nul
cd /d "%~dp0"
echo === RobotFace: instalacion en Windows ===
where py >nul 2>nul
if %errorlevel%==0 (
  py -3.12 -m venv .venv
) else (
  python -m venv .venv
)
if not exist .venv\Scripts\python.exe (
  echo.
  echo No pude crear el entorno de Python. Instala Python 3.12 de 64 bits desde https://www.python.org/downloads/
  echo y marca la casilla "Add python.exe to PATH". Despues vuelve a abrir este archivo.
  pause
  exit /b 1
)
.venv\Scripts\python.exe -m pip install --upgrade pip
.venv\Scripts\python.exe -m pip install -r requisitos_windows.txt
if errorlevel 1 (
  echo.
  echo Algo fallo al instalar. Copia el texto de arriba y revisa la guia INSTALAR_WINDOWS.md
  pause
  exit /b 1
)
if not exist clave_anthropic.txt (
  echo.
  echo FALTA LA CLAVE: crea el archivo clave_anthropic.txt en esta carpeta con tu clave de la API de Anthropic.
)
echo.
echo Listo. Ahora abre pagina.bat para encender el robot.
pause
