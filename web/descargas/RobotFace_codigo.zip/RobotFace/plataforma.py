# Lo que cambia entre macOS y Windows, en un solo lugar: el puerto del Arduino, la cámara,
# cómo se cierran los programas, la voz y el sonido. seguir.py, hablar.py y servidor.py lo usan
# para que el mismo código corra en los dos sistemas.
# ROBOT_COMO_PC=1 fuerza en un Mac las piezas que usa Windows (para probarlas sin un PC).
import os, queue, subprocess, sys, tempfile, threading, time
from pathlib import Path

WINDOWS = sys.platform == "win32"
MAC = sys.platform == "darwin" and not os.environ.get("ROBOT_COMO_PC")


def puerto_arduino():
    """El puerto serie del Arduino (COM3 en Windows, /dev/cu.usbmodem... en Mac) o None.
    Se puede fijar a mano con la variable de entorno ROBOT_PUERTO."""
    if os.environ.get("ROBOT_PUERTO"):
        return os.environ["ROBOT_PUERTO"]
    from serial.tools import list_ports
    claves = ("arduino", "usbmodem", "usbserial", "ch340", "ch341", "wch", "usb serial", "usb-serial", "cp210")
    buenos = sorted(p.device for p in list_ports.comports()
                    if any(k in f"{p.device} {p.description} {p.manufacturer or ''}".lower() for k in claves))
    return buenos[0] if buenos else None


def abrir_captura(indice):
    """Abre una cámara con el motor de cada sistema. En Windows pide 1280x720 (si no, entrega 640x480)."""
    import cv2
    if sys.platform == "darwin":
        return cv2.VideoCapture(indice, cv2.CAP_AVFOUNDATION)
    if WINDOWS:
        cam = cv2.VideoCapture(indice, cv2.CAP_DSHOW)
        cam.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
        cam.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
        return cam
    return cv2.VideoCapture(indice)


ORDEN_CAMARAS = [0, 1, 2, 3] if WINDOWS else [1, 0, 2, 3]   # en el Mac la 0 a veces es la del iPhone


def python_del_proyecto(raiz):
    return str(Path(raiz) / ".venv" / ("Scripts/python.exe" if WINDOWS else "bin/python"))


def reemplazar(origen, destino):
    """os.replace que no se cae en Windows cuando otro programa está leyendo el archivo de destino
    justo en ese momento: reintenta un par de veces y, si no puede, lo deja para la próxima."""
    for _ in range(3):
        try:
            os.replace(origen, destino)
            return True
        except PermissionError:
            time.sleep(0.01)
    return False


def matar_programa(archivo, suave=False):
    """Cierra todos los Python que estén corriendo ese archivo (por ejemplo "seguir.py")."""
    if WINDOWS:
        orden = ("Get-CimInstance Win32_Process -Filter \"Name like 'python%'\" | "
                 f"Where-Object {{ $_.CommandLine -like '*{archivo}*' }} | "
                 "ForEach-Object { Stop-Process -Id $_.ProcessId -Force }")
        subprocess.run(["powershell", "-NoProfile", "-Command", orden], capture_output=True)
    else:
        patron = f"[{archivo[0]}]{archivo[1:]}"   # así pkill no se encuentra a sí mismo
        subprocess.run(["pkill", "-INT" if suave else "-9", "-f", patron])


def programa_corriendo(archivo):
    """¿Hay algún Python corriendo ese archivo? (En Windows es lento: usar solo de vez en cuando.)"""
    if WINDOWS:
        orden = ("(Get-CimInstance Win32_Process -Filter \"Name like 'python%'\" | "
                 f"Where-Object {{ $_.CommandLine -like '*{archivo}*' }} | Measure-Object).Count")
        r = subprocess.run(["powershell", "-NoProfile", "-Command", orden], capture_output=True, text=True)
        return r.stdout.strip() not in ("", "0")
    return subprocess.run(["pgrep", "-f", f"[{archivo[0]}]{archivo[1:]}"], capture_output=True).returncode == 0


# ---------------------------------------------------------------------------------------------
# Voz en Windows: la que trae el sistema (SAPI), con un PowerShell que queda abierto para que cada
# frase tarde poco. Usa la primera voz en español instalada (Sabina, Helena, Laura...).
# ---------------------------------------------------------------------------------------------
class VozWindows:
    def __init__(self, voz_preferida="", velocidad=1):
        self.ps = subprocess.Popen(["powershell", "-NoProfile", "-NoLogo", "-Command", "-"],
                                   stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                   text=True, encoding="utf-8", errors="replace", bufsize=1)
        self.lineas = queue.Queue()
        threading.Thread(target=self._leer, daemon=True).start()
        elegir = (f"try {{ $s.SelectVoice('{voz_preferida}') }} catch {{}}; " if voz_preferida else
                  "$v = $s.GetInstalledVoices() | Where-Object { $_.VoiceInfo.Culture.Name -like 'es*' } | "
                  "Select-Object -First 1; if ($v) { $s.SelectVoice($v.VoiceInfo.Name) }; ")
        respuesta = self._orden("Add-Type -AssemblyName System.Speech; "
                                "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; " + elegir +
                                f"$s.Rate = {int(velocidad)}; "
                                "[Console]::Out.WriteLine('VOZ ' + $s.Voice.Name + ' | ' + $s.Voice.Culture.Name)", 30)
        if not respuesta or not respuesta.startswith("VOZ "):
            raise RuntimeError("PowerShell no respondió al preparar la voz")
        self.nombre = respuesta[4:]
        if "| es" not in self.nombre:
            print("AVISO: Windows no tiene una voz en español instalada, así que hablará con acento extranjero. "
                  "Agrégala en Configuración → Hora e idioma → Voz → Agregar voces → Español.")

    def _leer(self):
        for linea in self.ps.stdout:
            self.lineas.put(linea.strip())

    def _orden(self, texto, espera):
        self.ps.stdin.write(texto + "\n")
        self.ps.stdin.flush()
        try:
            while True:
                linea = self.lineas.get(timeout=espera)
                if linea:
                    return linea
        except queue.Empty:
            return None

    def a_archivo(self, texto, ruta_wav):
        """Genera la voz de `texto` en un archivo .wav."""
        ruta_texto = ruta_wav + ".txt"
        Path(ruta_texto).write_text(texto, encoding="utf-8")   # por archivo: así no se rompen las tildes
        comillas = lambda r: r.replace("'", "''")
        respuesta = self._orden(f"$t = [IO.File]::ReadAllText('{comillas(ruta_texto)}', [Text.Encoding]::UTF8); "
                                f"$s.SetOutputToWaveFile('{comillas(ruta_wav)}'); $s.Speak($t); "
                                "$s.SetOutputToNull(); [Console]::Out.WriteLine('OK')", 30)
        os.unlink(ruta_texto)
        if respuesta != "OK":
            raise RuntimeError(f"la voz de Windows no respondió ({respuesta})")


# ---------------------------------------------------------------------------------------------
# Sonido fuera del Mac: se reproduce con sounddevice (en el Mac se usa afplay). Tiene la misma
# forma que un proceso (poll / terminate / wait) para que hablar.py lo use igual.
# ---------------------------------------------------------------------------------------------
class Sonido:
    def __init__(self, datos, tasa):
        import numpy as np
        import sounddevice as sd
        self.sd = sd
        try:
            tasa_salida = int(sd.query_devices(kind="output")["default_samplerate"])
        except Exception:
            tasa_salida = 48000
        if tasa_salida != tasa:   # a la tasa del parlante: algunas tarjetas no aceptan 22050 Hz
            n = int(len(datos) * tasa_salida / tasa)
            datos = np.interp(np.linspace(0, len(datos) - 1, n), np.arange(len(datos)), datos).astype("float32")
        sd.play(datos, tasa_salida)
        self.fin = time.time() + len(datos) / tasa_salida + 0.05

    def poll(self):
        return None if time.time() < self.fin else 0

    def terminate(self):
        self.sd.stop()
        self.fin = 0

    def wait(self):
        pass


# ---------------------------------------------------------------------------------------------
# Entender la voz fuera del Mac: faster-whisper. Con tarjeta NVIDIA usa el modelo grande; sin ella,
# uno chico en el procesador (más rápido, se equivoca un poco más).
# ---------------------------------------------------------------------------------------------
def cargar_whisper_pc(modelo_gpu="large-v3-turbo", modelo_cpu="small"):
    from faster_whisper import WhisperModel
    import numpy as np
    elegido = os.environ.get("ROBOT_WHISPER")   # para forzar otro: tiny, base, small, medium, large-v3-turbo
    try:
        if os.environ.get("ROBOT_SIN_GPU"):
            raise RuntimeError("GPU desactivada")
        modelo = WhisperModel(elegido or modelo_gpu, device="cuda", compute_type="float16")
        list(modelo.transcribe(np.zeros(16000, dtype="float32"), language="es")[0])   # falla aquí si no hay CUDA
        print(f"Whisper {elegido or modelo_gpu} en la tarjeta de video (NVIDIA)")
        return modelo, 5
    except Exception:
        modelo = WhisperModel(elegido or modelo_cpu, device="cpu", compute_type="int8")
        print(f"Whisper {elegido or modelo_cpu} en el procesador (sin tarjeta NVIDIA)")
        return modelo, 1


def asegurar_utf8():
    """En Windows los archivos de texto se leen por defecto en la codificación antigua del sistema y
    los nombres con tilde se rompen. Si el programa no partió en modo UTF-8, se relanza a sí mismo
    con ese modo activado (los .bat y el servidor ya lo activan, así que normalmente no hace nada)."""
    if WINDOWS and not sys.flags.utf8_mode:
        os.environ["PYTHONUTF8"] = "1"
        sys.exit(subprocess.call([sys.executable, *sys.argv]))
